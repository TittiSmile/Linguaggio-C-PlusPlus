//Esercizio x l'uso struct, 
//lettura e scrittura file,  e algoritmi di ordinamento
// NOTA:
// E' possibile utilizzare la funzione 
// int atoi ( const char * str );
// Che converte c-stringhe in interi
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cmath>

#define MAX_M 10
#define MAX_N 30
#define MAX_LEN_STR 50
#define MAX_LEN_ARRAY 200

using namespace std;
 
struct sedutaEsame {
	int numEsercizi;
	int numStudenti;
	int voti[MAX_M][MAX_N];
	char nomeEsercizi[MAX_M][MAX_LEN_STR];
        char nomeStudenti[MAX_N][MAX_LEN_STR]; 
	int anno;
	int mese;
	int giorno;
	char nomeCorso[MAX_LEN_STR];
	
};

//Legge i risultati delle sedute di esame da File
int leggiEsami(char [],sedutaEsame []);
//Ordina le sedute di esame per data
void ordina(sedutaEsame [],int);
//Scrive i risultati delle sedute di esame in un file
void scriviEsami(char [],sedutaEsame [], int);

int main() {

int numEsami;
char nomeInFile[MAX_LEN_STR];
char nomeOutFile[MAX_LEN_STR];
sedutaEsame esami[MAX_LEN_ARRAY];

cout << "Dammi il nome del file in input:";
cin >> nomeInFile;

numEsami=leggiEsami(nomeInFile,esami);
ordina(esami,numEsami);
cout << "Dammi il nome del file in output:";
cin >> nomeOutFile;
scriviEsami(nomeOutFile,esami, numEsami);

return 0;
}

//Legge i risultati delle sedute di esame da File
int leggiEsami(char nomeInFile[],sedutaEsame esami[]){
int result;

return result;

}

//Ordina le sedute di esame per data
void ordina(sedutaEsame esami[],int numEsami){

}

//Scrive i risultati delle sedute di esame in un file
void scriviEsami(char nomeOutFile[],sedutaEsame esami[], int numEsami){

}

