#include <iostream>
#include <cstdlib>
#define MAX_LEN 100

using namespace std;
int confrontaStr(const char [],const char []);
int main () {
int res;
char s1[MAX_LEN];
char s2[MAX_LEN];
cout << "Prima stringa:";
cin >> s1;
cout << "Seconda stringa:";
cin >> s2;
res=confrontaStr(s1,s2);
switch(res) {
	case -1: cout<<"Prima stringa minore della seconda"<<endl;
	break;
	case 0: cout << "Le stringhe sono uguali"<<endl;
	break;
	case  1: cout << "prima stringa maggiore della seconda"<<endl;	
}

}

int confrontaStr(const char s1[],const char s2[]){
int result=0,i=0;
	while ((s1[i] != '\0' && s2[i]!='\0') && result==0) {
		if (s1[i]==s2[i]) ++i;
		else 
			if (s1[i]<s2[i]) 
				result=-1;
			else 
				result=1;		
	} 
	if (result==0 && (s1[i]!=s2[i])) {
		if (s1[i]=='\0') 
			result=-1;
		else
			result=1;
			
	}
return result;
}









