#include <iostream>
#include <cstdlib>
#define MAX_RIGHE 100
#define MAX_COLONNE 100
#define MAX_LEN 100
using namespace std;

bool controllaStr(const char [][MAX_COLONNE],const char [],int,int);

void riempiMatrice(char [][MAX_COLONNE],int,int);

int main () {
int m,n;
char M[MAX_RIGHE][MAX_COLONNE];
char s[MAX_LEN];
bool res;

cout<<"Numero righe, m=";
cin>>m;
cout << "Numero colonne, n=";
cin >>n;
cout << "Riempi Matrice:"<<endl;
riempiMatrice(M,m,n);
cout << "Dammi stringa: ";
cin >> s;
res=controllaStr(M,s,m,n);
if (res==true)
	cout << "La stringa e' presente!"<<endl;
else
	cout << "La stringa non e' presente!"<<endl;
return 0;
}
void riempiMatrice(char M[][MAX_COLONNE],int m, int n){
int i=0,j=0;
for (i=0;i<m;++i)
	for (j=0;j<n;++j) {
		cout << "M["<<i<<"]["<<j<<"]:";
		cin >> M[i][j];
	}
}

bool controllaInRiga(const char M[][MAX_COLONNE],const char s[],int riga,int n){
int result=false;
int i=0,j=0;
while (j<n && result==false) {
	if (M[riga][j]==s[0]) {
		i=1;
		while ((s[i]!='\0' && (j+i)<n) && s[i]==M[riga][j+i])	     	    
			++i;				
		
		if (s[i]=='\0') result=true;	
	} 
 	++j;
 }
return result;
}
 
bool controllaInColonna(const char M[][MAX_COLONNE],const char s[],int col,int m){
int result=false;
int i=0,j=0;
while (i<m && result==false) {
	if (M[i][col]==s[0]) {
		j=1;
		while ((s[j]!='\0' && (i+j)<m) && s[j]==M[i+j][col]) 
	     		++j;			
		if (s[j]=='\0') result=true;	
	} 
 	++i;
 }
return result;
} 

bool controllaStr(const char M[][MAX_COLONNE],const char s[],int m,int n){
bool result=false;
int i=0;
	while (i<m && result==false) {
		result=controllaInRiga(M,s,i,n);
		++i;
	}
	if (result==false) {
		i=0;
		while (i<n && result==false) {
			result=controllaInColonna(M,s,i,m);
			++i;
		}
	}
return result;
}








