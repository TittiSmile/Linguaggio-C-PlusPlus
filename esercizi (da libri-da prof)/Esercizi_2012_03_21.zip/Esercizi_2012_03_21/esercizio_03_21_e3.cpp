#include <iostream>
#include <cstdlib>
#include <cmath>
#define MAX_RIGHE 100
#define MAX_COLONNE 100
#define MAX_LEN 100
using namespace std;
void riempiMatrice(int [][MAX_COLONNE],int,int);
void visualizzaMatrice(const int [][MAX_COLONNE],int,int);
bool diagUguale(const int [][MAX_COLONNE],int, int, int,int) ;
void verifica(int [][MAX_COLONNE],int,int);
int main () {
int m,n,i1,j1,i2,j2;
int M[MAX_RIGHE][MAX_COLONNE];
char s[MAX_LEN];
bool res;

cout<<"Numero righe, m=";
cin>>m;
cout << "Numero colonne, n=";
cin >>n;
cout << "Riempi Matrice:"<<endl;
riempiMatrice(M,m,n);
visualizzaMatrice(M,m,n);
verifica(M,m,n);
cout<< "Dammi prima riga:";
cin >>i1;
cout<< "Dammi prima colonna:";
cin >>j1;
cout<< "Dammi seconda riga:";
cin >>i2;
cout<< "Dammi seconda colonna:";
cin >>j2;


res=diagUguale(M,i1, j1, i2,j2);
if (res) cout << "Condizione Verificata!"<<endl;
else cout << "Condizione Non Verificata!"<<endl;
}
void riempiMatrice(int M[][MAX_COLONNE],int m, int n){
int i=0,j=0;
for (i=0;i<m;++i)
	for (j=0;j<n;++j) {
		cout << "M["<<i<<"]["<<j<<"]:";
		cin >> M[i][j];
	}
}
void visualizzaMatrice(const int M[][MAX_COLONNE],int m,int n){
int i,j;
cout <<"Matrice:"<<endl;
for (i=0;i<m;++i) {
	for (j=0;j<n;++j)
		cout << " "<< M[i][j];
	cout <<endl;
	}
}
bool diagUguale(const int M[][MAX_COLONNE],int i1, int j1, int i2,int j2){
bool result=false;
	if (M[i1][j1]== M[i2][j2] && abs(j1-j2)==abs(i1-i2)) result=true;

return result;
}
void verifica(int M[][MAX_COLONNE],int m,int n){
	int i,j,h,k;
	int a=0;
	for (i=0;i<m;++i) {
		for (j=0;j<n;++j) {
			a=M[i][j];
			cout << "("<<i+1<<","<<j+1<<"): ";
			for (h=0;h<m;++h)
				for (k=0;k<n;++k)
					if (abs(i-h)==abs(j-k)) cout << " ("<<h+1<<","<<k+1<<"): ";
			cout <<endl;
		}
	}

}
